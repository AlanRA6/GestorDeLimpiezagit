
package glapp;

import glapp.Cuadrilla;
import glapp.Personal;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author edw09
 */
public class JFrameCuadrilla extends javax.swing.JFrame {

    DatabaseConnection con1 = new DatabaseConnection();
    Connection conet;
    DefaultTableModel modeloCuadrilla;
    DefaultTableModel modeloPersonal;
    Statement st;
    ResultSet rs;
    int idc;

    int cuadrilla_id;
    String nombre;
    String ubicacion;
    int jefeCuadrilla_id;
    
    public boolean cargarDatos() {
        // Verifica si alguno de los campos está vacío
        if (txtidCuadrilla.getText().isEmpty() || 
            txtNombreCuadrilla.getText().isEmpty() || 
            txtUbicacionCuadrilla.getText().isEmpty() ||
            txtidJefeCuadrilla.getText().isEmpty()) {

            // Muestra un mensaje de error
            JOptionPane.showMessageDialog(this, "Todos los campos deben estar llenos", "Error", 2);
            return false;
        }
        // Si todos los campos tienen datos, se procede a asignar los valores
        cuadrilla_id = Integer.parseInt(txtidCuadrilla.getText());
        nombre = txtNombreCuadrilla.getText();
        ubicacion = txtUbicacionCuadrilla.getText();
        jefeCuadrilla_id =  Integer.parseInt(txtidJefeCuadrilla.getText());
        
        return true;
    }
        
    public JFrameCuadrilla() {
        initComponents();
        setLocationRelativeTo(null);
                            // Inicializa los modelos
        modeloCuadrilla = (DefaultTableModel) tablaCuadrilla.getModel();
        modeloPersonal = (DefaultTableModel) tablaPersonal.getModel();
        
        consultar();
        consultar2();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtidCuadrilla = new javax.swing.JTextField();
        txtNombreCuadrilla = new javax.swing.JTextField();
        txtUbicacionCuadrilla = new javax.swing.JTextField();
        btnAgregarCuadrilla = new javax.swing.JButton();
        btnEditarCuadrilla = new javax.swing.JButton();
        btnEliminarCuadrilla = new javax.swing.JButton();
        btnBuscarPorIdCuadrilla = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        txtidJefeCuadrilla = new javax.swing.JTextField();
        btnAsignarMiembro = new javax.swing.JButton();
        txtIdPersonal = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        btnRemoverMiembro = new javax.swing.JButton();
        btnListarMiembros = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaCuadrilla = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        tablaPersonal = new javax.swing.JTable();
        txtAreaMiembros = new java.awt.TextArea();
        jPanel3 = new javax.swing.JPanel();
        btnAct = new javax.swing.JButton();
        btnJefeCuadrilla = new javax.swing.JButton();
        btnColonias = new javax.swing.JButton();
        btnPersonal = new javax.swing.JButton();
        btnDashboard = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setText("CUADRILLA");

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("OPERACIONES"));

        jLabel2.setText("ID de la Cuadrilla:");

        jLabel3.setText("Nombre :");

        jLabel4.setText("Ubicacion:");

        txtNombreCuadrilla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreCuadrillaActionPerformed(evt);
            }
        });

        btnAgregarCuadrilla.setText("Agregar");
        btnAgregarCuadrilla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarCuadrillaActionPerformed(evt);
            }
        });

        btnEditarCuadrilla.setText("Editar");
        btnEditarCuadrilla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarCuadrillaActionPerformed(evt);
            }
        });

        btnEliminarCuadrilla.setText("Eliminar");
        btnEliminarCuadrilla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarCuadrillaActionPerformed(evt);
            }
        });

        btnBuscarPorIdCuadrilla.setText("Buscar por ID");
        btnBuscarPorIdCuadrilla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarPorIdCuadrillaActionPerformed(evt);
            }
        });

        jLabel5.setText("ID de Jefe Cuadrilla:");

        txtidJefeCuadrilla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtidJefeCuadrillaActionPerformed(evt);
            }
        });

        btnAsignarMiembro.setText("Asignar Miembro");
        btnAsignarMiembro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAsignarMiembroActionPerformed(evt);
            }
        });

        txtIdPersonal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdPersonalActionPerformed(evt);
            }
        });

        jLabel6.setText("ID Miembro:");

        btnRemoverMiembro.setText("Remover Miembro");
        btnRemoverMiembro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRemoverMiembroActionPerformed(evt);
            }
        });

        btnListarMiembros.setText("Listar Miembros");
        btnListarMiembros.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnListarMiembrosActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtidJefeCuadrilla))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtidCuadrilla))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtNombreCuadrilla))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtUbicacionCuadrilla, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(223, 223, 223)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(btnAgregarCuadrilla)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnEditarCuadrilla)
                                .addGap(58, 58, 58))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(btnEliminarCuadrilla)
                                .addGap(18, 110, Short.MAX_VALUE)
                                .addComponent(btnBuscarPorIdCuadrilla)
                                .addGap(42, 42, 42))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(199, 199, 199)
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtIdPersonal, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnAsignarMiembro)
                        .addGap(18, 18, 18)
                        .addComponent(btnListarMiembros)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnRemoverMiembro)
                        .addContainerGap())))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtidCuadrilla, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAgregarCuadrilla)
                    .addComponent(btnEditarCuadrilla))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtNombreCuadrilla, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnEliminarCuadrilla)
                    .addComponent(btnBuscarPorIdCuadrilla))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtUbicacionCuadrilla, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtidJefeCuadrilla, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 31, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtIdPersonal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnRemoverMiembro)
                    .addComponent(btnAsignarMiembro)
                    .addComponent(btnListarMiembros))
                .addGap(2, 2, 2))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("DATOS"));

        tablaCuadrilla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "cuadrilla_id", "nombre", "ubicacion", "jefeCuadrilla_id"
            }
        ));
        tablaCuadrilla.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaCuadrillaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaCuadrilla);

        tablaPersonal.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "personal_id", "nombre", "cuadrilla_id"
            }
        ));
        jScrollPane2.setViewportView(tablaPersonal);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 777, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 367, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(91, 91, 91))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 143, Short.MAX_VALUE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("VENTANAS"));

        btnAct.setText("Actividad Limpieza");
        btnAct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActActionPerformed(evt);
            }
        });

        btnJefeCuadrilla.setText("Jefe Cuadrillas");
        btnJefeCuadrilla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnJefeCuadrillaActionPerformed(evt);
            }
        });

        btnColonias.setText("Colonias");
        btnColonias.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnColoniasActionPerformed(evt);
            }
        });

        btnPersonal.setText("Personal");
        btnPersonal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPersonalActionPerformed(evt);
            }
        });

        btnDashboard.setText("Dashboard");
        btnDashboard.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDashboardActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnJefeCuadrilla)
                .addGap(36, 36, 36)
                .addComponent(btnAct)
                .addGap(45, 45, 45)
                .addComponent(btnColonias)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 105, Short.MAX_VALUE)
                .addComponent(btnPersonal)
                .addGap(81, 81, 81)
                .addComponent(btnDashboard)
                .addGap(32, 32, 32))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAct)
                    .addComponent(btnColonias)
                    .addComponent(btnJefeCuadrilla)
                    .addComponent(btnPersonal)
                    .addComponent(btnDashboard))
                .addContainerGap(39, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(506, 506, 506)
                                    .addComponent(jLabel1))
                                .addGroup(layout.createSequentialGroup()
                                    .addContainerGap()
                                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGap(18, 18, 18)
                            .addComponent(txtAreaMiembros, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 1164, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtAreaMiembros, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(12, 12, 12)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 19, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnEliminarCuadrillaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarCuadrillaActionPerformed
    if (!txtidCuadrilla.getText().isEmpty()) {
        try {
            // Obtener el ID de la colonia desde el campo de texto ya validado
            int cuadrillaid = Integer.parseInt(txtidCuadrilla.getText());

            // Crear una nueva instancia de Colonias con el ID proporcionado
            Cuadrilla metodos = new Cuadrilla(cuadrillaid, "", "", -1); // Los otros campos no se usan, pero es necesario para el constructor

            // Llamar al método eliminar de la clase Colonias
            metodos.eliminar();
           
            JOptionPane.showMessageDialog(this, "Cuadrilla eliminada exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);

        } catch (NumberFormatException e) {
          
            JOptionPane.showMessageDialog(this, "El ID debe ser un número válido.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(this, "Por favor ingrese el ID de la cuadrilla a eliminar", "Error", JOptionPane.ERROR_MESSAGE);
    }
    consultar(); 
    consultar2();
    }//GEN-LAST:event_btnEliminarCuadrillaActionPerformed

    private void btnAgregarCuadrillaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarCuadrillaActionPerformed
        try {
            // Intenta convertir el texto a un número
            cuadrilla_id = Integer.parseInt(txtidCuadrilla.getText());

            // Llama a cargarDatosColonia para verificar los otros campos
            if (cargarDatos()) {
                // Crea un nuevo objeto de la clase Colonias y guarda la colonia
                Cuadrilla metodos = new Cuadrilla(cuadrilla_id, nombre, ubicacion,jefeCuadrilla_id);
                metodos.guardar();
            }
        } catch (NumberFormatException e) {
            // Muestra una alerta si el ID no es un número válido
            JOptionPane.showMessageDialog(this, "El ID debe ser un número entero.", "ERROR", JOptionPane.ERROR_MESSAGE);
        }
         consultar();
         consultar2();
    }//GEN-LAST:event_btnAgregarCuadrillaActionPerformed

    private void txtidJefeCuadrillaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtidJefeCuadrillaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtidJefeCuadrillaActionPerformed

    private void btnEditarCuadrillaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarCuadrillaActionPerformed
        try {
            // Verifica si todos los campos están completos y carga los datos
            if (cargarDatos()) {
                // Crea una instancia de JefeCuadrilla con los datos cargados y llama a actualizar
                Cuadrilla metodos = new Cuadrilla(cuadrilla_id, nombre, ubicacion,jefeCuadrilla_id );
                metodos.actualizar();
            }
        } catch (NumberFormatException e) {
            // Muestra un mensaje de error si el ID no es un número válido
            JOptionPane.showMessageDialog(this, "El ID debe ser un número válido.", "Error", JOptionPane.ERROR_MESSAGE);
        }
        consultar(); 
        consultar2();
    }//GEN-LAST:event_btnEditarCuadrillaActionPerformed

    private void btnBuscarPorIdCuadrillaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarPorIdCuadrillaActionPerformed
            // Obtener el ID ingresado por el usuario
         String idTexto = txtidCuadrilla.getText();

         if (idTexto.isEmpty()) {
             JOptionPane.showMessageDialog(this, "Por favor ingrese un ID para buscar.", "Error", JOptionPane.ERROR_MESSAGE);
             return; // Salir si el ID está vacío
         }

         try {
             
             int cuadrilla_id = Integer.parseInt(idTexto);
             
             Cuadrilla cuadrilla = Cuadrilla.obtenerPorId(cuadrilla_id);

             if (cuadrilla != null) {
                 // Si se encuentra la colonia, llenar los campos con los datos
                 txtidCuadrilla.setText(String.valueOf(cuadrilla.getCuadrilla_id()));
                 txtNombreCuadrilla.setText(cuadrilla.getNombre());
                 txtUbicacionCuadrilla.setText(cuadrilla.getUbicacion());
                 txtidJefeCuadrilla.setText(String.valueOf(cuadrilla.getJefeCuadrilla_id()));
             } else {
                 // Si no se encuentra la colonia
                 JOptionPane.showMessageDialog(this, "No se encontró una Cuadrilla con ese ID.", "Error", JOptionPane.ERROR_MESSAGE);
             }
         } catch (NumberFormatException e) {
             // Manejo de error si el ID no es un número válido
             JOptionPane.showMessageDialog(this, "El ID ingresado no es válido. Por favor ingrese un número.", "Error", JOptionPane.ERROR_MESSAGE);
         }        // TODO add your handling code here:
    }//GEN-LAST:event_btnBuscarPorIdCuadrillaActionPerformed

    private void tablaCuadrillaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaCuadrillaMouseClicked
     int fila = tablaCuadrilla.getSelectedRow();

     if (fila == -1) {
         // Si no se seleccionó ninguna fila
         JOptionPane.showMessageDialog(null, "No se seleccionó ninguna fila");
     } else {
         // Recupera los datos de la fila seleccionada
         int idc = Integer.parseInt(tablaCuadrilla.getValueAt(fila, 0).toString());  // colonia_id
         String nombre = (String) tablaCuadrilla.getValueAt(fila, 1);  // Nombre
         String ubicacion = (String) tablaCuadrilla.getValueAt(fila, 2);  // Dirección
         int idJefeCuadrilla = Integer.parseInt(tablaCuadrilla.getValueAt(fila, 3).toString());

         // Rellenar los campos con los datos de la colonia seleccionada
         txtidCuadrilla.setText(""+idc);  
         txtNombreCuadrilla.setText(nombre);  // Asignar el nombre al campo de texto
         txtUbicacionCuadrilla.setText(ubicacion);  // Asignar la dirección al campo de texto
         txtidJefeCuadrilla.setText(""+idJefeCuadrilla);  // Asignar el código postal al campo de texto

        
     }        
    }//GEN-LAST:event_tablaCuadrillaMouseClicked

    private void txtNombreCuadrillaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreCuadrillaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombreCuadrillaActionPerformed

    private void btnAsignarMiembroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAsignarMiembroActionPerformed

    try {
        // Obtener el ID de la cuadrilla y del miembro desde los campos de la UI
        int cuadrillaId = Integer.parseInt(txtidCuadrilla.getText());
        int miembroId = Integer.parseInt(txtIdPersonal.getText());

        // Validar que los IDs sean positivos
        if (cuadrillaId <= 0 || miembroId <= 0) {
            JOptionPane.showMessageDialog(null, "IDs inválidos. Por favor, verifique los datos.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Obtener la Cuadrilla desde la base de datos
        Cuadrilla cuadrilla = Cuadrilla.obtenerPorId(cuadrillaId);
        if (cuadrilla == null) {
            JOptionPane.showMessageDialog(null, "Cuadrilla no encontrada.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Obtener el Miembro (Personal) desde la base de datos
        Personal miembro = Personal.obtenerPorId(miembroId);
        if (miembro == null) {
            JOptionPane.showMessageDialog(null, "Miembro no encontrado.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Asignar el miembro a la cuadrilla
        cuadrilla.addMiembro(miembro);

        // Notificar al usuario
        JOptionPane.showMessageDialog(null, "Miembro asignado exitosamente a la cuadrilla.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
    } catch (NumberFormatException ex) {
        JOptionPane.showMessageDialog(null, "Por favor, introduzca IDs válidos.", "Error", JOptionPane.ERROR_MESSAGE);
    } catch (Exception ex) {
        JOptionPane.showMessageDialog(null, "Error al asignar el miembro: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
       consultar2();
    }//GEN-LAST:event_btnAsignarMiembroActionPerformed

    private void txtIdPersonalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdPersonalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdPersonalActionPerformed

    private void btnRemoverMiembroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRemoverMiembroActionPerformed
                                               
    try {
        // Obtener el ID de la cuadrilla y del miembro desde los campos de la UI
        int cuadrillaId = Integer.parseInt(txtidCuadrilla.getText());
        int miembroId = Integer.parseInt(txtIdPersonal.getText());

        // Validar que los IDs sean positivos
        if (cuadrillaId <= 0 || miembroId <= 0) {
            JOptionPane.showMessageDialog(null, "IDs inválidos. Por favor, verifique los datos.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Obtener la Cuadrilla desde la base de datos
        Cuadrilla cuadrilla = Cuadrilla.obtenerPorId(cuadrillaId);
        if (cuadrilla == null) {
            JOptionPane.showMessageDialog(null, "Cuadrilla no encontrada.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Obtener el Miembro (Personal) desde la base de datos
        Personal miembro = Personal.obtenerPorId(miembroId);
        if (miembro == null) {
            JOptionPane.showMessageDialog(null, "Miembro no encontrado.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Remover el miembro de la cuadrilla
        cuadrilla.removeMiembro(miembro);

        // Notificar al usuario
        JOptionPane.showMessageDialog(null, "Miembro removido exitosamente de la cuadrilla.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
    } catch (NumberFormatException ex) {
        JOptionPane.showMessageDialog(null, "Por favor, introduzca IDs válidos.", "Error", JOptionPane.ERROR_MESSAGE);
    } catch (Exception ex) {
        JOptionPane.showMessageDialog(null, "Error al remover el miembro: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }        
      consultar2();
    }//GEN-LAST:event_btnRemoverMiembroActionPerformed

    private void btnListarMiembrosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnListarMiembrosActionPerformed
                                                
    try {
        // Obtener el ID de la cuadrilla desde el campo de texto
        int cuadrillaId = Integer.parseInt(txtidCuadrilla.getText());

        // Validar que el ID sea positivo
        if (cuadrillaId <= 0) {
            JOptionPane.showMessageDialog(null, "ID de cuadrilla inválido. Por favor, verifique los datos.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Obtener la cuadrilla desde la base de datos
        Cuadrilla cuadrilla = Cuadrilla.obtenerPorId(cuadrillaId);
        if (cuadrilla == null) {
            JOptionPane.showMessageDialog(null, "Cuadrilla no encontrada.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Listar los miembros de la cuadrilla
        List<Personal> miembros = cuadrilla.listarMiembros();

        // Construir la cadena para mostrar en el JTextArea
        StringBuilder sb = new StringBuilder();
        if (miembros.isEmpty()) {
            sb.append("No se encontraron miembros en esta cuadrilla.\n");
        } else {
            for (Personal miembro : miembros) {
                sb.append("ID: ").append(miembro.getPersonal_id())
                  .append(", Nombre: ").append(miembro.getNombre())
                  .append(", ID_Cuadrilla: ").append(miembro.getCuadrillaId())
                  .append("\n");
            }
        }

        // Mostrar el resultado en un JTextArea
        txtAreaMiembros.setText(sb.toString());

    } catch (NumberFormatException ex) {
        JOptionPane.showMessageDialog(null, "Por favor, introduzca un ID válido.", "Error", JOptionPane.ERROR_MESSAGE);
    } catch (Exception ex) {
        JOptionPane.showMessageDialog(null, "Error al listar los miembros: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }

       consultar2();
    }//GEN-LAST:event_btnListarMiembrosActionPerformed

    private void btnActActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActActionPerformed

        JFramaActividadLimpieza frameAct = new JFramaActividadLimpieza();
        frameAct.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnActActionPerformed

    private void btnJefeCuadrillaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnJefeCuadrillaActionPerformed
        // Crea una nueva instancia del segundo JFrame
        JFrameJefeCuadrilla frameJefe = new JFrameJefeCuadrilla();

        // Muestra el segundo JFrame
        frameJefe.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_btnJefeCuadrillaActionPerformed

    private void btnColoniasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnColoniasActionPerformed

        JFrameColonias frameColonias = new JFrameColonias();
        frameColonias.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnColoniasActionPerformed

    private void btnPersonalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPersonalActionPerformed
        JFramePersonal framePersonal = new JFramePersonal();
        framePersonal.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnPersonalActionPerformed

    private void btnDashboardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDashboardActionPerformed
        JFrameDashboard frameDashboard = new JFrameDashboard();
        frameDashboard.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnDashboardActionPerformed

    
    void limpiarTabla(JTable tabla, DefaultTableModel modelo) {
        // Recorre las filas del modelo de abajo hacia arriba
        for (int i = modelo.getRowCount() - 1; i >= 0; i--) {
            modelo.removeRow(i);
        }
    }
    
    void consultar(){
        limpiarTabla(tablaCuadrilla, modeloCuadrilla); 
        String sql = "select * from cuadrilla";
        try {
            conet = con1.getConnection();
            st = conet.createStatement();
            rs = st.executeQuery(sql);
            Object [] cuadrilla = new Object[4];
            modeloCuadrilla = (DefaultTableModel) tablaCuadrilla.getModel();
            
            while(rs.next()){
                cuadrilla [0] = rs.getInt("cuadrilla_id");
                cuadrilla [1] = rs.getString("nombre");
                cuadrilla [2] = rs.getString("ubicacion");
                cuadrilla [3] = rs.getString("jefeCuadrilla_id");

                
                modeloCuadrilla.addRow(cuadrilla);
            }
            tablaCuadrilla.setModel(modeloCuadrilla);
        } catch(Exception e){
            
        }
    }
    
        
    void consultar2(){
        limpiarTabla(tablaPersonal, modeloPersonal); // Pasa la tabla y su modelo específico
        String sql = "select * from personal";
        try {
            conet = con1.getConnection();
            st = conet.createStatement();
            rs = st.executeQuery(sql);
            Object [] perso = new Object[3];
            modeloPersonal = (DefaultTableModel) tablaPersonal.getModel();
            
            while(rs.next()){
                perso [0] = rs.getInt("personal_id");
                perso [1] = rs.getString("nombre");
                perso [2] = rs.getInt("cuadrilla_id");
                modeloPersonal.addRow(perso);
            }
            tablaPersonal.setModel(modeloPersonal);
        } catch(Exception e){
            
        }
    }
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(JFrameCuadrilla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(JFrameCuadrilla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(JFrameCuadrilla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JFrameCuadrilla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new JFrameCuadrilla().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAct;
    private javax.swing.JButton btnAgregarCuadrilla;
    private javax.swing.JButton btnAsignarMiembro;
    private javax.swing.JButton btnBuscarPorIdCuadrilla;
    private javax.swing.JButton btnColonias;
    private javax.swing.JButton btnDashboard;
    private javax.swing.JButton btnEditarCuadrilla;
    private javax.swing.JButton btnEliminarCuadrilla;
    private javax.swing.JButton btnJefeCuadrilla;
    private javax.swing.JButton btnListarMiembros;
    private javax.swing.JButton btnPersonal;
    private javax.swing.JButton btnRemoverMiembro;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tablaCuadrilla;
    private javax.swing.JTable tablaPersonal;
    private java.awt.TextArea txtAreaMiembros;
    private javax.swing.JTextField txtIdPersonal;
    private javax.swing.JTextField txtNombreCuadrilla;
    private javax.swing.JTextField txtUbicacionCuadrilla;
    private javax.swing.JTextField txtidCuadrilla;
    private javax.swing.JTextField txtidJefeCuadrilla;
    // End of variables declaration//GEN-END:variables
}
