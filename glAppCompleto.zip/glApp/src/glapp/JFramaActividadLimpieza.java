/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package glapp;

import conexion.DatabaseConnection;
import glapp.ActividadLimpieza;
import glapp.Colonias;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;

public class JFramaActividadLimpieza extends javax.swing.JFrame {

    DatabaseConnection con1 = new DatabaseConnection();
    Connection conet;
    DefaultTableModel modelo;
    Statement st;
    ResultSet rs;
    int idc;
    
    int ActividadLimpieza_id;
    String descripcion;
    Date fecha;
    int colonia_id;
    int cuadrillaId;
    byte[] imagen;
    
    public JFramaActividadLimpieza() {
        initComponents();
        setLocationRelativeTo(null);
        
            // Inicializa el modelo de tabla vacío
    modelo = new DefaultTableModel(new Object[]{"ID", "Descripción", "Fecha", "Colonia ID", "Cuadrilla ID", "Imagen"}, 0);
    tablaActividadLimpieza.setModel(modelo); // Asocia el modelo a la tabla

    consultar();
    }
    
    
    public boolean cargarDatos() {
    // Verifica si alguno de los campos está vacío
    if (txtidActividadLimpieza.getText().isEmpty() || 
        txtFecha.getText().isEmpty() || 
        txtidColonia.getText().isEmpty() || 
        txtidCuadrilla.getText().isEmpty() ||
        txtAreaDescripcion.getText().isEmpty() ||
        Labelimagen.getIcon() == null) {

        // Muestra un mensaje de error
        JOptionPane.showMessageDialog(this, "Todos los campos deben estar llenos", "Error", JOptionPane.ERROR_MESSAGE);
        return false;
    }

    try {
        // Si todos los campos tienen datos, se procede a asignar los valores

        // Conversión del ID de la actividad
        ActividadLimpieza_id = Integer.parseInt(txtidActividadLimpieza.getText());
        
        // Descripción de la actividad
        descripcion = txtAreaDescripcion.getText();
        
        // Conversión de fecha (texto a Date)
        String fechaTexto = txtFecha.getText(); // Recupera el texto del JTextField
        SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd"); // Define el formato esperado
        fecha = formato.parse(fechaTexto); // Convierte el texto a un objeto Date
        
        // Conversión de IDs relacionados
        colonia_id = Integer.parseInt(txtidColonia.getText());
        cuadrillaId = Integer.parseInt(txtidCuadrilla.getText());

         // Conversión de la imagen (ruta a byte[])
        // La imagen ya está en el JLabel, obtenemos los bytes
        ImageIcon icono = (ImageIcon) Labelimagen.getIcon();
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        Image imagen = icono.getImage();
        BufferedImage bufferedImage = toBufferedImage(imagen);
        ImageIO.write(bufferedImage, "jpg", byteArrayOutputStream);  // Guarda como JPG o el formato que prefieras
        /*  imagen = byteArrayOutputStream.toByteArray();*/
        

    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Uno o más campos numéricos tienen valores inválidos.", "Error", JOptionPane.ERROR_MESSAGE);
        return false;

    } catch (ParseException e) {
        JOptionPane.showMessageDialog(this, "El formato de la fecha es inválido. Use 'yyyy-MM-dd'.", "Error", JOptionPane.ERROR_MESSAGE);
        return false;

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error al cargar la imagen o procesar los datos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        return false;
    }

    return true;
}
    // Convierte un objeto Image en un BufferedImage
    private BufferedImage toBufferedImage(Image img) {
    if (img instanceof BufferedImage) {
        return (BufferedImage) img;
    }

    // Crea una nueva imagen vacía
    BufferedImage bimage = new BufferedImage(img.getWidth(null), img.getHeight(null), BufferedImage.TYPE_INT_ARGB);

    // Dibuja la imagen en el BufferedImage
    Graphics2D bGr = bimage.createGraphics();
    bGr.drawImage(img, 0, 0, null);
    bGr.dispose();

    return bimage;
}
    
    void limpiarTabla() {
    if (modelo != null) {
        // Recorre las filas de la tabla de abajo hacia arriba
        for (int i = modelo.getRowCount() - 1; i >= 0; i--) {
            modelo.removeRow(i);
        }
    }
}

    void consultar(){
        limpiarTabla();
        String sql = "select * from actividadlimpieza";
        try {
            conet = con1.getConnection();
            st = conet.createStatement();
            rs = st.executeQuery(sql);
            
            if (modelo == null) {
            modelo = new DefaultTableModel(new Object[]{"ID", "Descripción", "Fecha", "Colonia ID", "Cuadrilla ID", "Imagen"}, 0);
            tablaActividadLimpieza.setModel(modelo);
        }
                       
            Object [] actividadlimpieza = new Object[6];
            modelo = (DefaultTableModel) tablaActividadLimpieza.getModel();
            
            while(rs.next()){
                actividadlimpieza [0] = rs.getInt("ActividadLimpieza_id");
                actividadlimpieza [1] = rs.getString("descripcion");
                actividadlimpieza [2] = rs.getString("fecha");
                actividadlimpieza [3] = rs.getInt("colonia_id");
                actividadlimpieza [4] = rs.getInt("cuadrilla_id");
                actividadlimpieza [5] = rs.getString("imagen");
                
                modelo.addRow(actividadlimpieza);
            }
            tablaActividadLimpieza.setModel(modelo);
        } catch(Exception e){
            
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        txtidActividadLimpieza = new javax.swing.JTextField();
        txtFecha = new javax.swing.JTextField();
        txtidColonia = new javax.swing.JTextField();
        txtidCuadrilla = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtAreaDescripcion = new javax.swing.JTextArea();
        Labelimagen = new javax.swing.JLabel();
        btnAgregarActividad = new javax.swing.JButton();
        btnEditarActividad = new javax.swing.JButton();
        btnEliminarActividad = new javax.swing.JButton();
        btnBuscarPorIdActividad = new javax.swing.JButton();
        btnCargarImagen = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tablaActividadLimpieza = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        btnColonias = new javax.swing.JButton();
        btnJefeCuadrilla = new javax.swing.JButton();
        btnCuadrilla = new javax.swing.JButton();
        btnPersonal = new javax.swing.JButton();
        btnDashboard = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Operaciones"));

        jLabel2.setText("ID de la Actividad:");

        jLabel3.setText("Fecha:");

        jLabel4.setText("ID de la Colonia:");

        jLabel5.setText("ID de la Cuadrilla:");

        jLabel7.setText("Descripcion:");

        jLabel8.setText("Imagen:");

        txtAreaDescripcion.setColumns(20);
        txtAreaDescripcion.setRows(5);
        jScrollPane1.setViewportView(txtAreaDescripcion);

        Labelimagen.setText("IMAGEN");

        btnAgregarActividad.setText("Agregar");
        btnAgregarActividad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActividadActionPerformed(evt);
            }
        });

        btnEditarActividad.setText("Editar");
        btnEditarActividad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActividadActionPerformed(evt);
            }
        });

        btnEliminarActividad.setText("Eliminar");
        btnEliminarActividad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActividadActionPerformed(evt);
            }
        });

        btnBuscarPorIdActividad.setText("Buscar por Id");
        btnBuscarPorIdActividad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarPorIdActividadActionPerformed(evt);
            }
        });

        btnCargarImagen.setText("Agregar Imagen");
        btnCargarImagen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCargarImagenActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtFecha))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtidColonia, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtidCuadrilla, javax.swing.GroupLayout.DEFAULT_SIZE, 95, Short.MAX_VALUE)
                                    .addComponent(txtidActividadLimpieza))))
                        .addGap(58, 58, 58)
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnAgregarActividad)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(1, 1, 1)
                                        .addComponent(btnEliminarActividad)))
                                .addGap(31, 31, 31)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnBuscarPorIdActividad)
                                    .addComponent(btnEditarActividad)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(37, 37, 37)
                                .addComponent(Labelimagen, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnCargarImagen)))))
                .addGap(10, 10, 10))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtidActividadLimpieza, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAgregarActividad)
                    .addComponent(btnEditarActividad))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(txtFecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnEliminarActividad)
                            .addComponent(btnBuscarPorIdActividad))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(txtidColonia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(txtidCuadrilla, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(47, 47, 47)
                                .addComponent(btnCargarImagen))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel7)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(Labelimagen, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(9, 9, 9)))
                .addGap(35, 35, 35))
        );

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setText("Actividad Limpieza");

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("DATOS"));

        tablaActividadLimpieza.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ActividadLimpieza_id", "descripcion", "fecha", "colonia_id", "cuadrilla_id", "imagen"
            }
        ));
        tablaActividadLimpieza.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaActividadLimpiezaMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tablaActividadLimpieza);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 575, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(19, Short.MAX_VALUE))
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("VENTANAS"));

        btnColonias.setText("Colonias");
        btnColonias.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnColoniasActionPerformed(evt);
            }
        });

        btnJefeCuadrilla.setText("Jefe Cuadrillas");
        btnJefeCuadrilla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnJefeCuadrillaActionPerformed(evt);
            }
        });

        btnCuadrilla.setText("Cuadrilla");
        btnCuadrilla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCuadrillaActionPerformed(evt);
            }
        });

        btnPersonal.setText("Personal");
        btnPersonal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPersonalActionPerformed(evt);
            }
        });

        btnDashboard.setText("Dashboard");
        btnDashboard.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDashboardActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnJefeCuadrilla)
                .addGap(37, 37, 37)
                .addComponent(btnColonias)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 40, Short.MAX_VALUE)
                .addComponent(btnCuadrilla)
                .addGap(38, 38, 38)
                .addComponent(btnPersonal)
                .addGap(18, 18, 18)
                .addComponent(btnDashboard)
                .addGap(22, 22, 22))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnColonias)
                    .addComponent(btnCuadrilla)
                    .addComponent(btnJefeCuadrilla)
                    .addComponent(btnPersonal)
                    .addComponent(btnDashboard))
                .addContainerGap(34, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(246, 246, 246)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(14, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 328, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(41, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnBuscarPorIdActividadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarPorIdActividadActionPerformed
        // Obtener el ID ingresado por el usuario
    String idTexto = txtidActividadLimpieza.getText();

    if (idTexto.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Por favor ingrese un ID para buscar.", "Error", JOptionPane.ERROR_MESSAGE);
        return; // Salir si el ID está vacío
    }

    try {
        // Convertir el texto a un número entero
        int ActividadLimpieza_id = Integer.parseInt(idTexto);

        // Llamar al método obtenerPorId para obtener la actividad con el ID proporcionado
        ActividadLimpieza actividad = ActividadLimpieza.obtenerPorId(ActividadLimpieza_id);

        if (actividad != null) {
            // Si se encuentra la actividad, llenar los campos con los datos
            txtidActividadLimpieza.setText(String.valueOf(actividad.getActividadLimpieza_id()));
            txtAreaDescripcion.setText(actividad.getDescripcion());
            SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");
            txtFecha.setText(formato.format(actividad.getFecha()));  // Formatea la fecha para mostrarla en el campo

            txtidColonia.setText(String.valueOf(actividad.getColonia_id()));
            txtidCuadrilla.setText(String.valueOf(actividad.getCuadrillaId()));

            // Mostrar la imagen si está disponible (suponiendo que 'imagen' esté en formato byte[])
            if (actividad.getImagen() != null) {
                ImageIcon icono = new ImageIcon(actividad.getImagen());
                Image image = icono.getImage();
                ImageIcon newImageIcon = new ImageIcon(image.getScaledInstance(100, 100, Image.SCALE_SMOOTH));  // Ajusta el tamaño
                Labelimagen.setIcon(newImageIcon);  // Asigna la imagen al JLabel
            } else {
                Labelimagen.setIcon(null);  // Si no hay imagen, limpia el JLabel
            }

        } else {
            // Si no se encuentra la actividad con ese ID
            JOptionPane.showMessageDialog(this, "No se encontró una actividad con ese ID.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } catch (NumberFormatException e) {
        // Manejo de error si el ID no es un número válido
        JOptionPane.showMessageDialog(this, "El ID ingresado no es válido. Por favor ingrese un número.", "Error", JOptionPane.ERROR_MESSAGE);
    } catch (Exception e) {
        // Manejo de cualquier otro error
        JOptionPane.showMessageDialog(this, "Ocurrió un error al buscar la actividad: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }        // TODO add your handling code here:
    }//GEN-LAST:event_btnBuscarPorIdActividadActionPerformed

    private void btnAgregarActividadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActividadActionPerformed
        // TODO add your handling code here:
        try {
            // Intenta convertir el texto a un número
            ActividadLimpieza_id = Integer.parseInt(txtidActividadLimpieza.getText());

            // Llama a cargarDatosColonia para verificar los otros campos
            if (cargarDatos()) {
                // Crea un nuevo objeto de la clase Colonias y guarda la colonia
                ActividadLimpieza metodos = new ActividadLimpieza( ActividadLimpieza_id, descripcion, fecha, colonia_id, cuadrillaId, imagen);
                metodos.guardar();
            }
        } catch (NumberFormatException e) {
            // Muestra una alerta si el ID no es un número válido
            JOptionPane.showMessageDialog(this, "El ID debe ser un número entero.", "ERROR", JOptionPane.ERROR_MESSAGE);
        }
         consultar();              
    }//GEN-LAST:event_btnAgregarActividadActionPerformed

    private void btnCargarImagenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCargarImagenActionPerformed
       // Abre un selector de archivos
    JFileChooser fileChooser = new JFileChooser();
    fileChooser.setFileFilter(new FileNameExtensionFilter("Imágenes", "jpg", "jpeg", "png", "gif"));
    int resultado = fileChooser.showOpenDialog(this);

    if (resultado == JFileChooser.APPROVE_OPTION) {
        // Obtiene la ruta del archivo seleccionado
        File archivoSeleccionado = fileChooser.getSelectedFile();
        String rutaImagen = archivoSeleccionado.getAbsolutePath();

        // Carga la imagen y ajusta el tamaño al JLabel
        ImageIcon iconoOriginal = new ImageIcon(rutaImagen);
        Image imagenEscalada = iconoOriginal.getImage().getScaledInstance(Labelimagen.getWidth(), Labelimagen.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon iconoEscalado = new ImageIcon(imagenEscalada);

        // Muestra la imagen en el JLabel
        Labelimagen.setIcon(iconoEscalado);
        Labelimagen.setText(""); // Opcional: limpia el texto del JLabel, si es necesario.

        // Guarda la ruta para usarla en el proceso de conversión a byte[]
        try {
            imagen = Files.readAllBytes(archivoSeleccionado.toPath());
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error al leer la imagen: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    }//GEN-LAST:event_btnCargarImagenActionPerformed

    private void btnEliminarActividadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActividadActionPerformed
 if (!txtidActividadLimpieza.getText().isEmpty()) {
        try {
            // Obtener el ID de la colonia desde el campo de texto ya validado
            int ActividadLimpiezaID = Integer.parseInt(txtidActividadLimpieza.getText());

            // Crear una nueva instancia de Colonias con el ID proporcionado
            // Los otros campos no se usan, pero es necesario para el constructor
           ActividadLimpieza metodos = new ActividadLimpieza( ActividadLimpiezaID, "", fecha, colonia_id, cuadrillaId, imagen);

            // Llamar al método eliminar de la clase Colonias
            metodos.eliminar();
           
            JOptionPane.showMessageDialog(this, "Actividad eliminada exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);

        } catch (NumberFormatException e) {
          
            JOptionPane.showMessageDialog(this, "El ID debe ser un número válido.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(this, "Por favor ingrese el ID de la Actividad a eliminar", "Error", JOptionPane.ERROR_MESSAGE);
    }
    consultar();           // TODO add your handling code here:
    }//GEN-LAST:event_btnEliminarActividadActionPerformed

    private void tablaActividadLimpiezaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaActividadLimpiezaMouseClicked
    // Obtiene la fila seleccionada
    int fila = tablaActividadLimpieza.getSelectedRow();

    if (fila == -1) {
        // Si no se seleccionó ninguna fila
        JOptionPane.showMessageDialog(null, "No se seleccionó ninguna fila");
    } else {
        // Recupera los datos de la fila seleccionada
        ActividadLimpieza_id = Integer.parseInt(tablaActividadLimpieza.getValueAt(fila, 0).toString()); // ActividadLimpieza_id
        descripcion = (String) tablaActividadLimpieza.getValueAt(fila, 1); // Descripción
        String fechaString = tablaActividadLimpieza.getValueAt(fila, 2).toString(); // Fecha como String
        colonia_id = Integer.parseInt(tablaActividadLimpieza.getValueAt(fila, 3).toString()); // colonia_id
        cuadrillaId = Integer.parseInt(tablaActividadLimpieza.getValueAt(fila, 4).toString()); // cuadrillaId
        
        // Convierte la fecha de String a Date
        SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");
        try {
            fecha = formato.parse(fechaString);
        } catch (ParseException ex) {
            JOptionPane.showMessageDialog(this, "Error al convertir la fecha", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Asigna los valores de la fila a los campos de texto
        txtidActividadLimpieza.setText(String.valueOf(ActividadLimpieza_id));
        txtAreaDescripcion.setText(descripcion);
        txtFecha.setText(fechaString); // La fecha en formato String
        txtidColonia.setText(String.valueOf(colonia_id));
        txtidCuadrilla.setText(String.valueOf(cuadrillaId));


    }    // TODO add your handling code here:
    }//GEN-LAST:event_tablaActividadLimpiezaMouseClicked

    private void btnEditarActividadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActividadActionPerformed
 try {
        // Verifica si todos los campos están completos y carga los datos
        if (cargarDatos()) {
            // Crea una instancia de ActividadLimpieza con los datos cargados
            ActividadLimpieza actividad = new ActividadLimpieza(ActividadLimpieza_id,descripcion,fecha,colonia_id,cuadrillaId,imagen);

            // Llama al método para actualizar en la base de datos
            actividad.actualizar(ActividadLimpieza_id, descripcion, fecha, colonia_id, cuadrillaId, imagen);

            // Muestra un mensaje de éxito
            JOptionPane.showMessageDialog(this, "La actividad se actualizó correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        }
    } catch (NumberFormatException e) {
        // Muestra un mensaje de error si algún ID no es un número válido
        JOptionPane.showMessageDialog(this, "Uno o más campos numéricos tienen valores inválidos.", "Error", JOptionPane.ERROR_MESSAGE);
    } catch (Exception e) {
        // Maneja cualquier otro error
        JOptionPane.showMessageDialog(this, "Ocurrió un error al actualizar la actividad: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }

    // Refresca la tabla para mostrar los cambios
    consultar();        // TODO add your handling code here:
    }//GEN-LAST:event_btnEditarActividadActionPerformed

    private void btnColoniasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnColoniasActionPerformed

        JFrameColonias frameColonias = new JFrameColonias();
        frameColonias.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnColoniasActionPerformed

    private void btnJefeCuadrillaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnJefeCuadrillaActionPerformed
        // Crea una nueva instancia del segundo JFrame
        JFrameJefeCuadrilla frameJefe = new JFrameJefeCuadrilla();

        // Muestra el segundo JFrame
        frameJefe.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_btnJefeCuadrillaActionPerformed

    private void btnCuadrillaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCuadrillaActionPerformed

        JFrameCuadrilla frameCuadrilla = new JFrameCuadrilla();
        frameCuadrilla.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnCuadrillaActionPerformed

    private void btnPersonalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPersonalActionPerformed
        JFramePersonal framePersonal = new JFramePersonal();
        framePersonal.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnPersonalActionPerformed

    private void btnDashboardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDashboardActionPerformed
        JFrameDashboard frameDashboard = new JFrameDashboard();
        frameDashboard.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnDashboardActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(JFramaActividadLimpieza.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(JFramaActividadLimpieza.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(JFramaActividadLimpieza.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JFramaActividadLimpieza.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new JFramaActividadLimpieza().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Labelimagen;
    private javax.swing.JButton btnAgregarActividad;
    private javax.swing.JButton btnBuscarPorIdActividad;
    private javax.swing.JButton btnCargarImagen;
    private javax.swing.JButton btnColonias;
    private javax.swing.JButton btnCuadrilla;
    private javax.swing.JButton btnDashboard;
    private javax.swing.JButton btnEditarActividad;
    private javax.swing.JButton btnEliminarActividad;
    private javax.swing.JButton btnJefeCuadrilla;
    private javax.swing.JButton btnPersonal;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tablaActividadLimpieza;
    private javax.swing.JTextArea txtAreaDescripcion;
    private javax.swing.JTextField txtFecha;
    private javax.swing.JTextField txtidActividadLimpieza;
    private javax.swing.JTextField txtidColonia;
    private javax.swing.JTextField txtidCuadrilla;
    // End of variables declaration//GEN-END:variables
}
