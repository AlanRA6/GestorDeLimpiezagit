
package glapp;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import conexion.DatabaseConnection;
import javax.swing.JOptionPane;

public class Personal {
    private int personal_id;
    private String nombre;
    private int cuadrillaId; // ID de la cuadrilla a la que pertenece

    // Constructor
    public Personal(int personal_id, String nombre, int cuadrillaId) {
        this.personal_id = personal_id;
        this.nombre = nombre;
        this.cuadrillaId = cuadrillaId;
    }

    // Métodos CRUD de Personal en la base de datos
    public void guardar() {
        String sql = "INSERT INTO personal (personal_id, nombre, cuadrilla_id) VALUES (?, ?, ?)";
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, this.personal_id);
            pstmt.setString(2, this.nombre);
            pstmt.setInt(3, this.cuadrillaId);
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(null,"Personal guardada exitosamente.");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,"Error al guardar el miembro: " + e.getMessage());
        }
    }

    public static Personal obtenerPorId(int personal_id) {
        String sql = "SELECT * FROM personal WHERE personal_id = ?";
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, personal_id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return new Personal(
                        rs.getInt("personal_id"),
                        rs.getString("nombre"),
                        rs.getInt("cuadrilla_id")
                );
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener el miembro: " + e.getMessage());
        }
        return null;
    }

    public void actualizar() {
        String sql = "UPDATE personal SET nombre = ?, cuadrilla_id = ? WHERE personal_id = ?";
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, this.nombre);
            pstmt.setInt(2, this.cuadrillaId);
            pstmt.setInt(3, this.personal_id);
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(null,"Personal actualizados exitosamente.");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,"Error al actualizar el miembro: " + e.getMessage());
        }
    }

    public void eliminar() {
        String sql = "DELETE FROM personal WHERE personal_id = ?";
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, this.personal_id);
            pstmt.executeUpdate();
            System.out.println("Miembro eliminado exitosamente.");
        } catch (SQLException e) {
            System.out.println("Error al eliminar el miembro: " + e.getMessage());
        }
    }

    // Métodos de manipulación de cuadrillas
    /*
    public void asignarCuadrilla(Cuadrilla cuadrilla) {
        this.cuadrillaId = cuadrilla.getCuadrilla_id();
        System.out.println("Miembro " + this.nombre + " asignado a la cuadrilla " + cuadrilla.getNombre());
    }

    public void removerDeCuadrilla() {
        this.cuadrillaId = 0; // Suponiendo que 0 indica que no pertenece a ninguna cuadrilla
        System.out.println("Miembro " + this.nombre + " removido de la cuadrilla.");
    }
    */
    
    // Asignar personal a una cuadrilla en la base de datos
    public void asignarCuadrilla(Cuadrilla cuadrilla) {
        String sql = "UPDATE personal SET cuadrilla_id = ? WHERE personal_id = ?";
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, cuadrilla.getCuadrilla_id());
            pstmt.setInt(2, this.personal_id);
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Personal " + this.nombre + " asignado a la cuadrilla " + cuadrilla.getNombre() + ".");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al asignar la cuadrilla: " + e.getMessage());
        }
    }

    // Remover un personal de una cuadrilla en la base de datos
    public void removerPersonalDeCuadrilla(Cuadrilla cuadrilla, Personal personal) {
        String sql = "UPDATE personal SET cuadrilla_id = NULL WHERE personal_id = ?";
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, personal.getPersonal_id()); // ID del personal a desvincular
            pstmt.executeUpdate();
            cuadrilla.listarMiembros().remove(personal); // Elimina el personal de la lista de la cuadrilla
            JOptionPane.showMessageDialog(null, "Personal " + personal.getNombre() +
                    " removido de la cuadrilla " + cuadrilla.getNombre());
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al remover el personal: " + e.getMessage());
        }
    }


    // Getters y setters
    public int getPersonal_id() {
        return personal_id;
    }

    public String getNombre() {
        return nombre;
    }

    public int getCuadrillaId() {
        return cuadrillaId;
    }

    public void setPersonal_id(int personal_id) {
        this.personal_id = personal_id;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setCuadrillaId(int cuadrillaId) {
        this.cuadrillaId = cuadrillaId;
    }
}

