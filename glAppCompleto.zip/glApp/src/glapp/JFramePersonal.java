
package glapp;

import conexion.DatabaseConnection;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class JFramePersonal extends javax.swing.JFrame {

    DatabaseConnection con1 = new DatabaseConnection();
    Connection conet;
    DefaultTableModel modeloPersonal;
    DefaultTableModel modeloCuadrilla;
    Statement st;
    ResultSet rs;
    int idc;
   
    int personal_id;
    String nombre;
    int cuadrilla_id;
    
    public JFramePersonal() {
        initComponents();
        setLocationRelativeTo(null);
            // Inicializa los modelos
        modeloPersonal = (DefaultTableModel) tablaPersonal.getModel();
        modeloCuadrilla = (DefaultTableModel) tablaCuadrilla.getModel();
        consultar();
        consultar2();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtIdPersonal = new javax.swing.JTextField();
        txtNombrePersonal = new javax.swing.JTextField();
        btnAgregarPersonal = new javax.swing.JButton();
        btnEditarPersonal = new javax.swing.JButton();
        btnEliminarPersonal = new javax.swing.JButton();
        btnBuscarPorIdPersonal = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        txtIdCuadrilla = new javax.swing.JTextField();
        btnAsignarCuadrilla = new javax.swing.JButton();
        btnRemoverDeCuadrilla = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaPersonal = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        tablaCuadrilla = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        btnAct = new javax.swing.JButton();
        btnJefeCuadrilla = new javax.swing.JButton();
        btnColonias = new javax.swing.JButton();
        btnCuadrilla = new javax.swing.JButton();
        btnDashboard = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setText("PERSONAL");

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("OPERACIONES"));

        jLabel2.setText("ID del Personal:");

        jLabel3.setText("Nombre:");

        btnAgregarPersonal.setText("Agregar");
        btnAgregarPersonal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarPersonalActionPerformed(evt);
            }
        });

        btnEditarPersonal.setText("Editar");
        btnEditarPersonal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarPersonalActionPerformed(evt);
            }
        });

        btnEliminarPersonal.setText("Eliminar");
        btnEliminarPersonal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarPersonalActionPerformed(evt);
            }
        });

        btnBuscarPorIdPersonal.setText("Buscar por ID");
        btnBuscarPorIdPersonal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarPorIdPersonalActionPerformed(evt);
            }
        });

        jLabel4.setText("ID de Cuadrilla:");

        btnAsignarCuadrilla.setText("Asignar Cuadrilla");
        btnAsignarCuadrilla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAsignarCuadrillaActionPerformed(evt);
            }
        });

        btnRemoverDeCuadrilla.setText("Remover de Cuadrilla");
        btnRemoverDeCuadrilla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRemoverDeCuadrillaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtIdPersonal))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtNombrePersonal, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtIdCuadrilla)))
                .addGap(129, 129, 129)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnAgregarPersonal)
                    .addComponent(btnEliminarPersonal))
                .addGap(46, 46, 46)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnBuscarPorIdPersonal)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(btnEditarPersonal)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnAsignarCuadrilla)
                .addGap(63, 63, 63)
                .addComponent(btnRemoverDeCuadrilla)
                .addGap(128, 128, 128))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtIdPersonal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAgregarPersonal)
                    .addComponent(btnEditarPersonal))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(txtNombrePersonal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(txtIdCuadrilla, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnEliminarPersonal)
                            .addComponent(btnBuscarPorIdPersonal))))
                .addGap(59, 59, 59)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnRemoverDeCuadrilla)
                    .addComponent(btnAsignarCuadrilla))
                .addContainerGap(43, Short.MAX_VALUE))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("DATOS"));

        tablaPersonal.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "personal_id", "nombre", "cuadrilla_id"
            }
        ));
        tablaPersonal.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaPersonalMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaPersonal);

        tablaCuadrilla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "cuadrilla_id", "nombre", "ubicacion", "jefeCuadrilla_id"
            }
        ));
        jScrollPane2.setViewportView(tablaCuadrilla);

        jLabel5.setText("Personal");

        jLabel6.setText("Cuadrilla");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 579, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 435, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(27, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(268, 268, 268)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel6)
                .addGap(203, 203, 203))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("VENTANAS"));

        btnAct.setText("Actividad Limpieza");
        btnAct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActActionPerformed(evt);
            }
        });

        btnJefeCuadrilla.setText("Jefe Cuadrillas");
        btnJefeCuadrilla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnJefeCuadrillaActionPerformed(evt);
            }
        });

        btnColonias.setText("Colonias");
        btnColonias.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnColoniasActionPerformed(evt);
            }
        });

        btnCuadrilla.setText("Cuadrilla");
        btnCuadrilla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCuadrillaActionPerformed(evt);
            }
        });

        btnDashboard.setText("Dashboard");
        btnDashboard.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDashboardActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnJefeCuadrilla)
                .addGap(36, 36, 36)
                .addComponent(btnAct)
                .addGap(45, 45, 45)
                .addComponent(btnColonias)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 81, Short.MAX_VALUE)
                .addComponent(btnCuadrilla)
                .addGap(81, 81, 81)
                .addComponent(btnDashboard)
                .addGap(32, 32, 32))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAct)
                    .addComponent(btnColonias)
                    .addComponent(btnJefeCuadrilla)
                    .addComponent(btnCuadrilla)
                    .addComponent(btnDashboard))
                .addContainerGap(39, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel1)
                                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel1)
                .addGap(12, 12, 12)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(38, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAgregarPersonalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarPersonalActionPerformed

            // Verifica si los datos se cargan correctamente
        try {
            // Intenta convertir el texto a un número
            personal_id = Integer.parseInt(txtIdPersonal.getText());

            // Llama a cargarDatosColonia para verificar los otros campos
            if (cargarDatos()) {
                // Crea un nuevo objeto de la clase Personal y guarda la colonia
                Personal metodos = new Personal(personal_id, nombre, cuadrilla_id);
                metodos.guardar();
            }
        } catch (NumberFormatException e) {
            // Muestra una alerta si el ID no es un número válido
            JOptionPane.showMessageDialog(this, "El ID debe ser un número entero.", "ERROR", JOptionPane.ERROR_MESSAGE);
        }
         consultar();      
    }//GEN-LAST:event_btnAgregarPersonalActionPerformed

    private void btnEliminarPersonalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarPersonalActionPerformed

        if (!txtIdPersonal.getText().isEmpty()) {
            try {
                
                int personalId = Integer.parseInt(txtIdPersonal.getText());

                // Crear una nueva instancia de Personal con el ID proporcionado
                Personal metodos = new Personal(personalId, "", -1); 

                metodos.eliminar();

                JOptionPane.showMessageDialog(this, " eliminada exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);

            } catch (NumberFormatException e) {

                JOptionPane.showMessageDialog(this, "El ID debe ser un número válido.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Por favor ingrese el ID de la colonia a eliminar", "Error", JOptionPane.ERROR_MESSAGE);
        }
        consultar(); 
    }//GEN-LAST:event_btnEliminarPersonalActionPerformed

    private void btnEditarPersonalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarPersonalActionPerformed
        try {
            // Verifica si todos los campos están completos y carga los datos
            if (cargarDatos()) {
               
                Personal metodos = new Personal(personal_id, nombre, cuadrilla_id);
                metodos.actualizar();
            }
        } catch (NumberFormatException e) {
            // Muestra un mensaje de error si el ID no es un número válido
            JOptionPane.showMessageDialog(this, "El ID debe ser un número válido.", "Error", JOptionPane.ERROR_MESSAGE);
        }
        consultar();
    }//GEN-LAST:event_btnEditarPersonalActionPerformed

    private void btnBuscarPorIdPersonalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarPorIdPersonalActionPerformed
            // Obtener el ID ingresado por el usuario
         String idTexto = txtIdPersonal.getText();

         if (idTexto.isEmpty()) {
             JOptionPane.showMessageDialog(this, "Por favor ingrese un ID para buscar.", "Error", JOptionPane.ERROR_MESSAGE);
             return; // Salir si el ID está vacío
         }

         try {
             
             int personal_id = Integer.parseInt(idTexto);
             
             Personal persona = Personal.obtenerPorId(personal_id);

             if (persona != null) {
                 // Si se encuentra la persona, llenar los campos con los datos
                 txtIdPersonal.setText(String.valueOf(persona.getPersonal_id()));
                 txtNombrePersonal.setText(persona.getNombre());
                 txtIdCuadrilla.setText(String.valueOf(persona.getCuadrillaId()));
             } else {
                 // Si no se encuentra la persona
                 JOptionPane.showMessageDialog(this, "No se encontró una Personal con ese ID.", "Error", JOptionPane.ERROR_MESSAGE);
             }
         } catch (NumberFormatException e) {
             // Manejo de error si el ID no es un número válido
             JOptionPane.showMessageDialog(this, "El ID ingresado no es válido. Por favor ingrese un número.", "Error", JOptionPane.ERROR_MESSAGE);
         }
    }//GEN-LAST:event_btnBuscarPorIdPersonalActionPerformed

    private void tablaPersonalMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaPersonalMouseClicked
 // Obtiene la fila seleccionada
     int fila = tablaPersonal.getSelectedRow();

     if (fila == -1) {
         // Si no se seleccionó ninguna fila
         JOptionPane.showMessageDialog(null, "No se seleccionó ninguna fila");
     } else {
         // Recupera los datos de la fila seleccionada
         int idc = Integer.parseInt(tablaPersonal.getValueAt(fila, 0).toString());  
         String nombre = (String) tablaPersonal.getValueAt(fila, 1);  
         int cuadrilla_id = Integer.parseInt(tablaPersonal.getValueAt(fila, 2).toString()); 
   
         txtIdPersonal.setText(""+idc);  
         txtNombrePersonal.setText(nombre); 
         txtIdCuadrilla.setText(""+cuadrilla_id);  
         
     }   
    }//GEN-LAST:event_tablaPersonalMouseClicked

    private void btnAsignarCuadrillaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAsignarCuadrillaActionPerformed
        try {
            // Obtener los IDs de personal y cuadrilla desde los campos de la UI
            int personalId = Integer.parseInt(txtIdPersonal.getText());
            int cuadrillaId = Integer.parseInt(txtIdCuadrilla.getText());

            // Validar que los IDs sean positivos
            if (personalId <= 0 || cuadrillaId <= 0) {
                JOptionPane.showMessageDialog(null, "IDs inválidos. Por favor, verifique los datos.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Obtener el Personal desde la base de datos
            Personal personal = Personal.obtenerPorId(personalId);
            if (personal == null) {
                JOptionPane.showMessageDialog(null, "Personal no encontrado.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Obtener la Cuadrilla desde la base de datos (esto requiere un método Cuadrilla.obtenerPorId())
            Cuadrilla cuadrilla = Cuadrilla.obtenerPorId(cuadrillaId);
            if (cuadrilla == null) {
                JOptionPane.showMessageDialog(null, "Cuadrilla no encontrada.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Asignar la cuadrilla al personal
            personal.asignarCuadrilla(cuadrilla);

            // Notificar al usuario
            JOptionPane.showMessageDialog(null, "Personal asignado a la cuadrilla exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Por favor, introduzca IDs válidos.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Error al asignar la cuadrilla: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }    
        consultar();
    }//GEN-LAST:event_btnAsignarCuadrillaActionPerformed

    private void btnRemoverDeCuadrillaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRemoverDeCuadrillaActionPerformed
        try {
                // Obtener IDs desde los campos de la UI
                int cuadrillaId = Integer.parseInt(txtIdCuadrilla.getText());
                int personalId = Integer.parseInt(txtIdPersonal.getText());

                // Validar que los IDs sean positivos
                if (cuadrillaId <= 0 || personalId <= 0) {
                    JOptionPane.showMessageDialog(null, "IDs inválidos. Por favor, verifique los datos.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Obtener la Cuadrilla desde la base de datos
                Cuadrilla cuadrilla = Cuadrilla.obtenerPorId(cuadrillaId);
                if (cuadrilla == null) {
                    JOptionPane.showMessageDialog(null, "Cuadrilla no encontrada.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Obtener el Personal desde la base de datos
                Personal personal = Personal.obtenerPorId(personalId);
                if (personal == null) {
                    JOptionPane.showMessageDialog(null, "Personal no encontrado.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Remover el personal de la cuadrilla
                personal.removerPersonalDeCuadrilla(cuadrilla, personal);

                // Notificar al usuario
                JOptionPane.showMessageDialog(null, "Personal removido exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Por favor, introduzca IDs válidos.", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Error al remover el personal: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }        
        consultar();
    }//GEN-LAST:event_btnRemoverDeCuadrillaActionPerformed

    private void btnActActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActActionPerformed

        JFramaActividadLimpieza frameAct = new JFramaActividadLimpieza();
        frameAct.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnActActionPerformed

    private void btnJefeCuadrillaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnJefeCuadrillaActionPerformed
        // Crea una nueva instancia del segundo JFrame
        JFrameJefeCuadrilla frameJefe = new JFrameJefeCuadrilla();

        // Muestra el segundo JFrame
        frameJefe.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_btnJefeCuadrillaActionPerformed

    private void btnColoniasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnColoniasActionPerformed

        JFrameColonias frameColonias = new JFrameColonias();
        frameColonias.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnColoniasActionPerformed

    private void btnCuadrillaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCuadrillaActionPerformed
        JFrameCuadrilla frameCuadrilla = new JFrameCuadrilla();
        frameCuadrilla.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnCuadrillaActionPerformed

    private void btnDashboardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDashboardActionPerformed
        JFrameDashboard frameDashboard = new JFrameDashboard();
        frameDashboard.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnDashboardActionPerformed
    
    public boolean cargarDatos() {
        // Verifica si alguno de los campos está vacío
        if (txtIdPersonal.getText().isEmpty() || 
            txtNombrePersonal.getText().isEmpty() ||
            txtIdCuadrilla.getText().isEmpty()) {

            // Muestra un mensaje de error
            JOptionPane.showMessageDialog(this, "Todos los campos deben estar llenos", "Error", 2);
            return false;
        }
        // Si todos los campos tienen datos, se procede a asignar los valores
        personal_id = Integer.parseInt(txtIdPersonal.getText());
        nombre = txtNombrePersonal.getText();
        cuadrilla_id = Integer.parseInt(txtIdCuadrilla.getText());
        return true;
    }
    
    void limpiarTabla(JTable tabla, DefaultTableModel modelo) {
        // Recorre las filas del modelo de abajo hacia arriba
        for (int i = modelo.getRowCount() - 1; i >= 0; i--) {
            modelo.removeRow(i);
        }
    }

    
    void consultar(){
        limpiarTabla(tablaPersonal, modeloPersonal);
        String sql = "select * from personal";
        try {
            conet = con1.getConnection();
            st = conet.createStatement();
            rs = st.executeQuery(sql);
            Object [] persona = new Object[3];
            modeloPersonal = (DefaultTableModel) tablaPersonal.getModel();
            
            while(rs.next()){
                persona [0] = rs.getInt("personal_id");
                persona [1] = rs.getString("nombre");
                persona [2] = rs.getString("cuadrilla_id");
                modeloPersonal.addRow(persona);
            }
            tablaPersonal.setModel(modeloPersonal);
        } catch(Exception e){
            
        }
    }
 
    void consultar2(){
        limpiarTabla(tablaCuadrilla, modeloCuadrilla); // Pasa la tabla y su modelo específico
        String sql = "select * from cuadrilla";
        try {
            conet = con1.getConnection();
            st = conet.createStatement();
            rs = st.executeQuery(sql);
            Object [] cuadri = new Object[4];
            modeloCuadrilla = (DefaultTableModel) tablaCuadrilla.getModel();
            
            while(rs.next()){
                cuadri [0] = rs.getInt("cuadrilla_id");
                cuadri [1] = rs.getString("nombre");
                cuadri [2] = rs.getString("ubicacion");
                cuadri [3] = rs.getInt("jefeCuadrilla_id");
                modeloCuadrilla.addRow(cuadri);
            }
            tablaCuadrilla.setModel(modeloCuadrilla);
        } catch(Exception e){
            
        }
    }
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(JFramePersonal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(JFramePersonal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(JFramePersonal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JFramePersonal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new JFramePersonal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAct;
    private javax.swing.JButton btnAgregarPersonal;
    private javax.swing.JButton btnAsignarCuadrilla;
    private javax.swing.JButton btnBuscarPorIdPersonal;
    private javax.swing.JButton btnColonias;
    private javax.swing.JButton btnCuadrilla;
    private javax.swing.JButton btnDashboard;
    private javax.swing.JButton btnEditarPersonal;
    private javax.swing.JButton btnEliminarPersonal;
    private javax.swing.JButton btnJefeCuadrilla;
    private javax.swing.JButton btnRemoverDeCuadrilla;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tablaCuadrilla;
    private javax.swing.JTable tablaPersonal;
    private javax.swing.JTextField txtIdCuadrilla;
    private javax.swing.JTextField txtIdPersonal;
    private javax.swing.JTextField txtNombrePersonal;
    // End of variables declaration//GEN-END:variables
}
