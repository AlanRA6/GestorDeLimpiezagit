
package glapp;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;
import javax.swing.*;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Map;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;


public class JFrameDashboard extends javax.swing.JFrame {


    
    public JFrameDashboard() {
           initComponents();
           setLocationRelativeTo(null);
      //  consultar();
        }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        panelActividadesColonia = new javax.swing.JPanel();
        btnGraficar = new javax.swing.JButton();
        panelPersonalporCuadrilla = new javax.swing.JPanel();
        panelActividadporMes = new javax.swing.JPanel();
        panelActividadporCuadrilla = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        btnAct = new javax.swing.JButton();
        btnJefeCuadrilla = new javax.swing.JButton();
        btnColonias = new javax.swing.JButton();
        btnCuadrilla = new javax.swing.JButton();
        btnPersonal = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setText("DASHBOARD");

        javax.swing.GroupLayout panelActividadesColoniaLayout = new javax.swing.GroupLayout(panelActividadesColonia);
        panelActividadesColonia.setLayout(panelActividadesColoniaLayout);
        panelActividadesColoniaLayout.setHorizontalGroup(
            panelActividadesColoniaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        panelActividadesColoniaLayout.setVerticalGroup(
            panelActividadesColoniaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        btnGraficar.setText("Graficar");
        btnGraficar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGraficarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelPersonalporCuadrillaLayout = new javax.swing.GroupLayout(panelPersonalporCuadrilla);
        panelPersonalporCuadrilla.setLayout(panelPersonalporCuadrillaLayout);
        panelPersonalporCuadrillaLayout.setHorizontalGroup(
            panelPersonalporCuadrillaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 500, Short.MAX_VALUE)
        );
        panelPersonalporCuadrillaLayout.setVerticalGroup(
            panelPersonalporCuadrillaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 266, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout panelActividadporMesLayout = new javax.swing.GroupLayout(panelActividadporMes);
        panelActividadporMes.setLayout(panelActividadporMesLayout);
        panelActividadporMesLayout.setHorizontalGroup(
            panelActividadporMesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 546, Short.MAX_VALUE)
        );
        panelActividadporMesLayout.setVerticalGroup(
            panelActividadporMesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout panelActividadporCuadrillaLayout = new javax.swing.GroupLayout(panelActividadporCuadrilla);
        panelActividadporCuadrilla.setLayout(panelActividadporCuadrillaLayout);
        panelActividadporCuadrillaLayout.setHorizontalGroup(
            panelActividadporCuadrillaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        panelActividadporCuadrillaLayout.setVerticalGroup(
            panelActividadporCuadrillaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 269, Short.MAX_VALUE)
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("VENTANAS"));

        btnAct.setText("Actividad Limpieza");
        btnAct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActActionPerformed(evt);
            }
        });

        btnJefeCuadrilla.setText("Jefe Cuadrillas");
        btnJefeCuadrilla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnJefeCuadrillaActionPerformed(evt);
            }
        });

        btnColonias.setText("Colonias");
        btnColonias.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnColoniasActionPerformed(evt);
            }
        });

        btnCuadrilla.setText("Cuadrilla");
        btnCuadrilla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCuadrillaActionPerformed(evt);
            }
        });

        btnPersonal.setText("Personal");
        btnPersonal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPersonalActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnJefeCuadrilla)
                .addGap(36, 36, 36)
                .addComponent(btnAct)
                .addGap(45, 45, 45)
                .addComponent(btnColonias)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 81, Short.MAX_VALUE)
                .addComponent(btnCuadrilla)
                .addGap(81, 81, 81)
                .addComponent(btnPersonal)
                .addGap(32, 32, 32))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAct)
                    .addComponent(btnColonias)
                    .addComponent(btnJefeCuadrilla)
                    .addComponent(btnCuadrilla)
                    .addComponent(btnPersonal))
                .addContainerGap(24, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(panelActividadporMes, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panelActividadesColonia, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(panelPersonalporCuadrilla, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panelActividadporCuadrilla, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(17, 17, 17))
            .addGroup(layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(btnGraficar)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(205, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(498, 498, 498))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(172, 172, 172))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(btnGraficar)
                .addGap(32, 32, 32)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(panelPersonalporCuadrilla, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panelActividadesColonia, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(panelActividadporCuadrilla, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panelActividadporMes, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(31, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGraficarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGraficarActionPerformed
          GraficarActividadporColonia();
          GraficarPersonalporCuadrilla();
          GraficarActividadesPorMes();
          GraficarActividadesPorCuadrilla();
    }//GEN-LAST:event_btnGraficarActionPerformed

    private void btnActActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActActionPerformed

        JFramaActividadLimpieza frameAct = new JFramaActividadLimpieza();
        frameAct.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnActActionPerformed

    private void btnJefeCuadrillaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnJefeCuadrillaActionPerformed
        // Crea una nueva instancia del segundo JFrame
        JFrameJefeCuadrilla frameJefe = new JFrameJefeCuadrilla();

        // Muestra el segundo JFrame
        frameJefe.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_btnJefeCuadrillaActionPerformed

    private void btnColoniasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnColoniasActionPerformed

        JFrameColonias frameColonias = new JFrameColonias();
        frameColonias.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnColoniasActionPerformed

    private void btnCuadrillaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCuadrillaActionPerformed
        JFrameCuadrilla frameCuadrilla = new JFrameCuadrilla();
        frameCuadrilla.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnCuadrillaActionPerformed

    private void btnPersonalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPersonalActionPerformed
        JFramePersonal framePersonal = new JFramePersonal();
        framePersonal.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnPersonalActionPerformed

    void GraficarActividadporColonia(){

            // Obtener datos desde la base de datos
            DashboardData data = new DashboardData();
            Map<String, Integer> actividadesPorColonia = data.getActividadPorLugar();

            // Crear el dataset para la gráfica
            DefaultCategoryDataset dataset = new DefaultCategoryDataset();
            for (Map.Entry<String, Integer> entry : actividadesPorColonia.entrySet()) {
                dataset.addValue(entry.getValue(), "Actividades", entry.getKey());
            }

            // Crear la gráfica de barras
            JFreeChart grafico_barras = ChartFactory.createBarChart3D(
                    "Actividades por Colonia",  // Título
                    "Colonias",               // Eje X
                    "Número de Actividades",  // Eje Y
                    dataset
                    
            );

            CategoryPlot plot = grafico_barras.getCategoryPlot();
            
                    // Configurar el rango del eje Y
            NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
            rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits()); // Asegura números enteros
            rangeAxis.setRange(0, 30); // Ranho ajustable del eje Y
    
             // Limpiar el panel antes de agregar el nuevo gráfico
            panelActividadesColonia.removeAll();  // Elimina cualquier componente previamente agregado
        
            // Crear el ChartPanel y agregarlo al panelActividadesColonia
            ChartPanel chartPanel = new ChartPanel(grafico_barras);
            chartPanel.setMouseWheelEnabled(true);
            chartPanel.setPreferredSize(panelActividadesColonia.getSize());  // Se ajusta al tamaño del panel
            panelActividadesColonia.setLayout(new BorderLayout());

            // Agregar el gráfico al panel
            panelActividadesColonia.add(chartPanel, BorderLayout.CENTER);

            // Actualizar la interfaz gráfica para que se vea el cambio
            panelActividadesColonia.revalidate();
            panelActividadesColonia.repaint();
    }
    
    
   void GraficarPersonalporCuadrilla() {

        // Obtener los datos desde la base de datos
        DashboardData data = new DashboardData();
        Map<String, Integer> personalPorCuadrilla = data.getPersonalPorCuadrilla();

        // Crear el dataset para la gráfica
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        for (Map.Entry<String, Integer> entry : personalPorCuadrilla.entrySet()) {
            dataset.addValue(entry.getValue(), "Personal", entry.getKey());
        }

        // Crear la gráfica de barras
        JFreeChart grafico_barras = ChartFactory.createBarChart3D(
                "Personal por Cuadrilla",  // Título
                "Cuadrillas",              // Eje X
                "Número de Personas",      // Eje Y
                dataset
        );

        CategoryPlot plot = grafico_barras.getCategoryPlot();

        // Configurar el rango del eje Y
        NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
        rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits()); // Asegura números enteros
        rangeAxis.setRange(0, 30); // Rango ajustable del eje Y

        // Limpiar el panel antes de agregar el nuevo gráfico
        panelPersonalporCuadrilla.removeAll();  // Elimina cualquier componente previamente agregado

        // Crear el ChartPanel y agregarlo al panelPersonalporCuadrilla
        ChartPanel chartPanel = new ChartPanel(grafico_barras);
        chartPanel.setMouseWheelEnabled(true);
        chartPanel.setPreferredSize(panelPersonalporCuadrilla.getSize());  // Se ajusta al tamaño del panel
        panelPersonalporCuadrilla.setLayout(new BorderLayout());

        // Agregar el gráfico al panel
        panelPersonalporCuadrilla.add(chartPanel, BorderLayout.CENTER);

        // Actualizar la interfaz gráfica para que se vea el cambio
        panelPersonalporCuadrilla.revalidate();
        panelPersonalporCuadrilla.repaint();
    }
   
   
   void GraficarActividadesPorMes() {
        // Obtener los datos desde la base de datos
        DashboardData data = new DashboardData();
        Map<String, Integer> actividadesPorMes = data.getActividadPorMes();

        // Crear el TimeSeries para las actividades
        TimeSeries series = new TimeSeries("Actividades");
        
        for (Map.Entry<String, Integer> entry : actividadesPorMes.entrySet()) {
            try {
                // Convertir la fecha en formato año-mes a un objeto Date
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
                java.util.Date date = sdf.parse(entry.getKey());
                series.addOrUpdate(new org.jfree.data.time.Month(date), entry.getValue());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        // Crear el dataset
        TimeSeriesCollection dataset = new TimeSeriesCollection(series);

        // Crear el gráfico de líneas
        JFreeChart chart = ChartFactory.createTimeSeriesChart(
                "Actividades por Mes", // Título
                "Mes",                 // Eje X
                "Número de Actividades",  // Eje Y
                dataset,               // Dataset
                false,                 // Leyenda
                true,                  // Herramientas
                false                  // URL
        );

        // Configurar el rango del eje Y
        Plot plot = chart.getPlot();
        if (plot instanceof org.jfree.chart.plot.XYPlot) {
            org.jfree.chart.plot.XYPlot xyPlot = (org.jfree.chart.plot.XYPlot) plot;
            NumberAxis rangeAxis = (NumberAxis) xyPlot.getRangeAxis();
            rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
            rangeAxis.setRange(0, 30);  // Ajusta el rango según sea necesario
        }

        // Limpiar el panel antes de agregar el nuevo gráfico
        panelActividadporMes.removeAll();  // Elimina cualquier componente previamente agregado

        // Crear el ChartPanel y agregarlo al panelActividadesColonia
        ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setMouseWheelEnabled(true);
        chartPanel.setPreferredSize(panelActividadporMes.getSize());  // Se ajusta al tamaño del panel
        panelActividadporMes.setLayout(new BorderLayout());

        // Agregar el gráfico al panel
        panelActividadporMes.add(chartPanel, BorderLayout.CENTER);

        // Actualizar la interfaz gráfica para que se vea el cambio
        panelActividadporMes.revalidate();
        panelActividadporMes.repaint();
    }
   
   
   
   void GraficarActividadesPorCuadrilla() {
        // Obtener datos desde la base de datos
        DashboardData data = new DashboardData();
        Map<String, Integer> actividadesPorCuadrilla = data.getActividadesPorCuadrilla();

        // Crear el dataset para la gráfica de pastel
        DefaultPieDataset dataset = new DefaultPieDataset();
        for (Map.Entry<String, Integer> entry : actividadesPorCuadrilla.entrySet()) {
            dataset.setValue(entry.getKey(), entry.getValue());  // Asocia el nombre de la cuadrilla con el número de actividades
        }

        // Crear el gráfico de pastel
        JFreeChart grafico_pastel = ChartFactory.createPieChart(
                "Actividades por Cuadrilla",  // Título
                dataset,                     // Dataset
                true,                        // Mostrar leyenda
                true,                        // Incluir detalles del gráfico
                false                        // Incluir tooltips
        );

        // Limpiar el panel antes de agregar el nuevo gráfico
        panelActividadporCuadrilla.removeAll();  // Elimina cualquier componente previamente agregado

        // Crear el ChartPanel y agregarlo al panelActividadesColonia
        ChartPanel chartPanel = new ChartPanel(grafico_pastel);
        chartPanel.setMouseWheelEnabled(true);
        chartPanel.setPreferredSize(panelActividadporCuadrilla.getSize());  // Se ajusta al tamaño del panel
        panelActividadporCuadrilla.setLayout(new BorderLayout());

        // Agregar el gráfico al panel
        panelActividadporCuadrilla.add(chartPanel, BorderLayout.CENTER);

        // Actualizar la interfaz gráfica para que se vea el cambio
       panelActividadporCuadrilla.revalidate();
        panelActividadporCuadrilla.repaint();
    }


        public static void main(String args[]) {
            /* Set the Nimbus look and feel */
            //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
            /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
             * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
             */
            try {
                for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                    if ("Nimbus".equals(info.getName())) {
                        javax.swing.UIManager.setLookAndFeel(info.getClassName());
                        break;
                    }
                }
            } catch (ClassNotFoundException ex) {
                java.util.logging.Logger.getLogger(JFrameDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
            } catch (InstantiationException ex) {
                java.util.logging.Logger.getLogger(JFrameDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
            } catch (IllegalAccessException ex) {
                java.util.logging.Logger.getLogger(JFrameDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
            } catch (javax.swing.UnsupportedLookAndFeelException ex) {
                java.util.logging.Logger.getLogger(JFrameDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
            }
            //</editor-fold>

            /* Create and display the form */
            java.awt.EventQueue.invokeLater(new Runnable() {
                public void run() {
                    new JFrameDashboard().setVisible(true);
                }
            });
    }
   
        
        

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAct;
    private javax.swing.JButton btnColonias;
    private javax.swing.JButton btnCuadrilla;
    private javax.swing.JButton btnGraficar;
    private javax.swing.JButton btnJefeCuadrilla;
    private javax.swing.JButton btnPersonal;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel panelActividadesColonia;
    private javax.swing.JPanel panelActividadporCuadrilla;
    private javax.swing.JPanel panelActividadporMes;
    private javax.swing.JPanel panelPersonalporCuadrilla;
    // End of variables declaration//GEN-END:variables
}
