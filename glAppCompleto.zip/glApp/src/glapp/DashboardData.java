
package glapp;

import java.sql.*;
import java.util.HashMap;
import java.util.Map;
import conexion.DatabaseConnection;

public class DashboardData {

         // Método para obtener el número de actividades por colonia
    public Map<String, Integer> getActividadPorLugar() {
        Map<String, Integer> actividadesPorColonia = new HashMap<>();
        String sql = "SELECT c.nombre AS colonia, COUNT(a.ActividadLimpieza_id) AS total_actividades " +
                     "FROM colonias c " +
                     "LEFT JOIN actividadlimpieza a ON c.colonia_id = a.colonia_id " +
                     "GROUP BY c.nombre";

        // Utilizar la conexión del Singleton
        try (Connection con = DatabaseConnection.getInstance().getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                String colonia = rs.getString("colonia");
                int totalActividades = rs.getInt("total_actividades");
                actividadesPorColonia.put(colonia, totalActividades);
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener datos: " + e.getMessage());
        }
        //System.out.println("Datos recuperados: " + actividadesPorColonia);

        return actividadesPorColonia;
    }
    
    // Método para obtener el número de personal por cuadrilla
    public Map<String, Integer> getPersonalPorCuadrilla() {
        Map<String, Integer> personalPorCuadrilla = new HashMap<>();
        String sql = "SELECT cuadrilla.nombre AS cuadrilla, COUNT(p.personal_id) AS total_personal " +
                     "FROM cuadrilla " +
                     "LEFT JOIN personal p ON cuadrilla.cuadrilla_id = p.cuadrilla_id " +
                     "GROUP BY cuadrilla.nombre";

        // Utilizar la conexión del Singleton
        try (Connection con = DatabaseConnection.getInstance().getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                String cuadrilla = rs.getString("cuadrilla");
                int totalPersonal = rs.getInt("total_personal");
                personalPorCuadrilla.put(cuadrilla, totalPersonal);
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener datos: " + e.getMessage());
        }

        return personalPorCuadrilla;
    }
    
    
    // Método para Gráfico de Líneas de Actividad a lo largo del tiempo
    public Map<String, Integer> getActividadPorMes() {
        Map<String, Integer> actividadesPorMes = new HashMap<>();
        
        String sql = "SELECT DATE_FORMAT(fecha, '%Y-%m') AS mes, COUNT(ActividadLimpieza_id) AS total_actividades " +
                     "FROM actividadlimpieza " +
                     "GROUP BY mes";

        try (Connection con = DatabaseConnection.getInstance().getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                String mes = rs.getString("mes");
                int totalActividades = rs.getInt("total_actividades");
                actividadesPorMes.put(mes, totalActividades);
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener datos: " + e.getMessage());
        }

        return actividadesPorMes;
    }
    
    
    // Método para obtner numero de actividades por cuadrilla
    public Map<String, Integer> getActividadesPorCuadrilla() {
        Map<String, Integer> actividadesPorCuadrilla = new HashMap<>();
        String sql = "SELECT cu.nombre AS cuadrilla, COUNT(al.ActividadLimpieza_id) AS total_actividades " +
                     "FROM cuadrilla cu " +
                     "LEFT JOIN actividadlimpieza al ON cu.cuadrilla_id = al.cuadrilla_id " +
                     "GROUP BY cu.cuadrilla_id";

        // Utilizar la conexión del Singleton
        try (Connection con = DatabaseConnection.getInstance().getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                String cuadrilla = rs.getString("cuadrilla");
                int totalActividades = rs.getInt("total_actividades");
                actividadesPorCuadrilla.put(cuadrilla, totalActividades);
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener datos: " + e.getMessage());
        }

        return actividadesPorCuadrilla;
    }

}
